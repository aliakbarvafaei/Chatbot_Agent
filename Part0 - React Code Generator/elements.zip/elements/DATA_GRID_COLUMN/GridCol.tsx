function GridCol(props: any) {
  return <span {...props}>{props.children}</span>;
}

export default GridCol;
