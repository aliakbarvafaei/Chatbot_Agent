import { KdpaPaginationGrid } from "kdpa-components";

function Pagination(props: any) {
  return (
    <KdpaPaginationGrid
      page={1}
      pageCount={3}
      pageSize={10}
      totalCount={24}
      {...props}
    />
  );
}

export default Pagination;
