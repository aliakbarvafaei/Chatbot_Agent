import React from "react";
import { Pagination, PaginationProps } from "@mui/material";
import { KdpaSelect, KdpaMenuItem } from "../Selects";
import "./kdpaPaginationGrid.scss";

export interface KdpaPaginationGridProps extends PaginationProps {
  onChange?: (page: any, pageSize: number) => void;
  totalCount?: number;
  pageCount?: number;
  pageTotalCount?: { value: string; label: string }[];
  disabled?: boolean;
  page?: number;
  pageSize?: number;
  rowsPerPageText?: string;
  totalCountText?: string;
  showRowPerPage?: boolean;
  showTotalCount?: boolean;
}

const KdpaPaginationGrid: React.FC<KdpaPaginationGridProps> = ({
  onChange,
  totalCount = 0,
  page = 1,
  pageSize = 10,
  pageTotalCount = [
    {
      value: "5",
      label: "5",
    },
    {
      value: "10",
      label: "10",
    },
    {
      value: "15",
      label: "15",
    },
    {
      value: "20",
      label: "20",
    },
  ],
  disabled,
  showRowPerPage = true,
  showTotalCount = true,
  rowsPerPageText,
  totalCountText,
  ...props
}) => {
  function handleChangeTotalCount(e: React.ChangeEvent<HTMLSelectElement>) {
    if (onChange) onChange(1, +e.target.value);
  }

  function handleChangePage(e: any, page: number) {
    if (onChange) onChange(page, pageSize);
  }

  return (
    <div className="kdpa-pagination">
      <div className="kdpa-pagination-content">
        {showRowPerPage && (
          <>
            <div className="paginationInput-lable">
              <span className="text-muted">{rowsPerPageText}</span>
            </div>
            <div className="kdpa-pagination-container">
              <KdpaSelect
                onChange={(e: any) => handleChangeTotalCount(e)}
                value={pageSize}
                disabled={disabled}
              >
                {pageTotalCount?.length === 0 ? (
                  <KdpaMenuItem>بدون مقدار</KdpaMenuItem>
                ) : (
                  pageTotalCount?.map((item, index) => (
                    <KdpaMenuItem key={index} value={item?.value}>
                      {item?.label}
                    </KdpaMenuItem>
                  ))
                )}
              </KdpaSelect>
            </div>
          </>
        )}
        {showTotalCount && (
          <div className="paginationInput-lable kdpa-pagination-container-lable">
            <span className="text-muted kdpa-pagination-container-span">
              {totalCountText}
            </span>
            <span>{totalCount}</span>
          </div>
        )}
      </div>

      <Pagination
        variant="outlined"
        shape="rounded"
        {...props}
        page={page}
        count={Math.ceil(totalCount / pageSize)}
        onChange={handleChangePage}
        disabled={disabled}
        sx={{
          ...props.sx,
          "& .MuiPagination-ul li": {
            margin: "0 3px",
            borderRadius: "20",
          },
          "& .MuiPagination-ul li :hover": {
            borderColor: (theme) =>
              theme.palette.primary.main || "var(--bs-primary,#7367F0)",
          },
          "& .Mui-selected": {
            backgroundColor: (theme) =>
              (theme.palette.primary.main || "var(--bs-primary,#7367F0)") +
              " !important",
            color: "white",
          },
        }}
      />
    </div>
  );
};

export default KdpaPaginationGrid;
