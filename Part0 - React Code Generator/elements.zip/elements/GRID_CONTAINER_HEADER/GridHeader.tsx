import { useState } from "react";

import { useParams } from "react-router-dom";
import { KdpaTypography } from "kdpa-components";

import i18n from "@/configs/i18n";
import { Menu } from "@mui/material";
import { AiOutlinePlus } from "react-icons/ai";
import { useMutation } from "@tanstack/react-query";
import { generateIconElement } from "@/utility/shared";
import { getInitialNode } from "@/core/utils/insertNode";
import { useEditorStore } from "@/core/store/editorStore";
import ElementWrapper from "@/core/components/Element/ElementWrapper";
import {
  propertyExtractor,
  stylesExtractor,
} from "@/core/utils/kdlValueExtractor";
import {
  createComponentElementMutation,
  CreateComponentElementVars,
} from "@/services/GraphQL/ComponentElement/mutations/componentElementCreate";

import { ElementTypes } from "..";
import Button from "../Button/ButtonElement";
import IconListItem from "./components/IconListItem";

export const iconsList = [
  {
    //  "افزودن"
    title: i18n.t("add"),
    icon: "AiOutlinePlus$$#fff$$18",
  },
  {
    //  "جستجو"
    title: i18n.t("search"),
    icon: "FiSearch$$#fff$$18",
  },
  {
    //  "بروزرسانی"
    title: i18n.t("refresh"),
    icon: "HiRefresh$$#fff$$18",
  },
  {
    //  "سفارشی"
    title: i18n.t("common.custom"),
    icon: "HiRefresh$$#fff$$18",
  },
];

function GridHeader({ id }: { id: string }) {
  const { componentId = "" } = useParams();
  const isPreview = useEditorStore((state) => state.isPreview);

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const nodes = useEditorStore((store) => store.nodes);

  const node = useEditorStore((store) => store.nodes[id]);
  const style = stylesExtractor(node.node.style);
  const attrs = propertyExtractor(node.node.attrs);

  const headerButtons = node.node.children;

  const { mutate: mutatCreateElement } = useMutation({
    mutationFn: createComponentElementMutation,
  });

  const addNode = useEditorStore((store) => store.addNode);

  const handleCreateButton = (icon: string) => {
    const parentId = id;

    const iconElement = generateIconElement(icon);

    let kdlNode = getInitialNode(ElementTypes.BUTTON);

    kdlNode = {
      ...kdlNode,
      parentId,
      attrs: {},

      style: {
        ...kdlNode.style,
        marginLeft: {
          type: "static",
          content: "6px",
        },
        minWidth: {
          type: "static",
          content: "35px",
        },
        minHeight: {
          type: "static",
          content: "35px",
        },
        padding: {
          type: "static",
          content: "4px 8px",
        },
        borderRadius: {
          type: "static",
          content: "4px",
        },
      },

      innerChildren: [iconElement],
    };

    const vars: CreateComponentElementVars = {
      name: "",
      englishName: "",
      description: "",
      controlType: ElementTypes.BUTTON,
      elementText: JSON.stringify(kdlNode),
      ownerComponentID: componentId as string,
      elementType: "PUBLIC",
      parentElementId: parentId,
    };

    mutatCreateElement(vars, {
      onSuccess(data) {
        const {
          guid: nodeId,
          englishName,
          name,
        } = data.componentElement_create.data;
        const newNode = {
          nodeType: ElementTypes.BUTTON,
          node: kdlNode,
          meta: {
            name,
            englishName,
            elementText: JSON.stringify(kdlNode),
            ownerComponentID: componentId,
          },
        };
        addNode(parentId, nodeId, newNode);
      },
    });
  };

  return (
    <div
      id={id}
      className="flex flex-row items-center w-full justify-between"
      style={{ ...style, marginBottom: "12px" }}
      {...attrs}
    >
      <KdpaTypography variant="h6">{attrs.title}</KdpaTypography>
      <span className="flex items-center flex-row gap-2">
        {!isPreview && (
          <span
            onClick={handleClick}
            className="border-[2px] border-dashed border-text_light rounded cursor-pointer w-9 h-9 flex items-center justify-center"
          >
            <AiOutlinePlus size={20} style={{ color: "primary.text_light " }} />
          </span>
        )}

        {open && (
          <Menu
            id="basic-menu"
            anchorEl={anchorEl}
            open={open}
            anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
            transformOrigin={{ vertical: "top", horizontal: "left" }}
            sx={{ maxHeight: "300px", marginTop: "0px" }}
            onClose={handleClose}
            MenuListProps={{
              "aria-labelledby": "basic-button",
            }}
            dir="rtl"
          >
            {iconsList.map((action) => (
              <IconListItem
                key={action.icon}
                action={action}
                handleCreateButton={handleCreateButton}
              />
            ))}
          </Menu>
        )}

        <div className="flex items-center">
          {headerButtons?.map((buttonId) => {
            const nodeButton = nodes[buttonId];
            const attrs = propertyExtractor(nodeButton.node.attrs);
            const styles = stylesExtractor(nodeButton.node.style);
            return (
              <ElementWrapper id={buttonId}>
                <Button id={buttonId} style={styles} {...attrs} />
              </ElementWrapper>
            );
          })}
        </div>
      </span>
    </div>
  );
}

export default GridHeader;
