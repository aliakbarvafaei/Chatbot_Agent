import Droppable from "@/core/components/DnD/Droppable";
import { useEditorStore } from "@/core/store/editorStore";
import {
  propertyExtractor,
  stylesExtractor,
} from "@/core/utils/kdlValueExtractor";

function GridPanelView({ id }: { id: string }) {
  const isPreview = useEditorStore((state) => state.isPreview);
  const node = useEditorStore((store) => store.nodes[id]);
  const style = stylesExtractor(node.node.style);
  const attrs = propertyExtractor(node.node.attrs);

  return (
    <div
      id={id}
      className={`w-full${
        isPreview
          ? ""
          : " p-3 border border-dashed border-text_light border-opacity-30"
      }`}
    >
      <div>
        <span>{attrs.label}</span>
        <Droppable id={id} className="p-4" style={style} {...attrs} />
      </div>
    </div>
  );
}

export default GridPanelView;
