import Droppable from "@/core/components/DnD/Droppable";
import { useEditorStore } from "@/core/store/editorStore";

function GridContainer(props: any) {
  const isPreview = useEditorStore((state) => state.isPreview);

  return (
    <div
      className={`p-6 flex flex-col gap-3 ${
        isPreview
          ? ""
          : "border border-dashed dark:bg-dark_bg_body border-text_light border-opacity-30 "
      }`}
    >
      <Droppable id={props.id} />
    </div>
  );
}

export default GridContainer;
