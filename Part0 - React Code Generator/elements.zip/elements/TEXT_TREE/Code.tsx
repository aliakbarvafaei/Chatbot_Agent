import { useEffect, useState } from "react";

import { useTheme } from "@mui/material";
import CheckboxTree, {
  CheckboxProps,
  OnCheckNode,
  OnExpandNode,
} from "react-checkbox-tree";

// mui icons

import {
  MdCheckBox,
  MdKeyboardArrowLeft,
  MdKeyboardArrowDown,
  MdCheckBoxOutlineBlank,
  MdIndeterminateCheckBox,
} from "react-icons/md";

// default styles
import "react-checkbox-tree/lib/react-checkbox-tree.css";

// override some default styles
import "./KdTreeField.scss";
import { useTreeFieldHelper } from "./useTreeFieldHelper";

export interface KdTreeFieldProps extends Partial<CheckboxProps> {
  data: unknown[];
  multiSelect?: boolean;
  defaultValue?: string[] | string;
  getOptionLabel?: ((data: any) => string) | undefined;
  getOptionIcon?: ((data: any) => string) | undefined;
  getOptionValue?: ((data: any) => string) | undefined;
  getOptionParent?: ((data: any) => string) | undefined;
  noDataText?: string;
  [key: string]: any;
}

function KdTreeField({
  data,
  defaultValue = [],
  onExpand,
  multiSelect = true,
  getOptionValue,
  getOptionIcon,
  getOptionLabel,
  getOptionParent,
  noDataText = "no data",
  ...props
}: KdTreeFieldProps) {
  const theme = useTheme();
  // build data of tree
  const { buildTree, renderTreeToSpecificFieldName, findAllExpanded } =
    useTreeFieldHelper();
  const convertedData = renderTreeToSpecificFieldName({
    data,
    getOptionLabel,
    getOptionIcon,
    getOptionValue,
    getOptionParent,
  });
  const nodes = buildTree(convertedData);

  const [checkedNodes, setCheckedNodes] = useState<string[]>([]);
  const [expandedNodes, setExpandedNodes] = useState<string[]>(
    [nodes?.[0]?.value] ?? []
  );

  // handle default value
  useEffect(() => {
    if (defaultValue) {
      if (typeof defaultValue === "string") {
        setExpandedNodes(findAllExpanded(convertedData, defaultValue));
        setCheckedNodes([defaultValue]);
      } else {
        const expanded: string[] = [];
        defaultValue.forEach((value) => {
          expanded.push(...findAllExpanded(convertedData, value));
        });
        setExpandedNodes(expanded);
        setCheckedNodes([...defaultValue]);
      }
    }
  }, []);

  // apply all changes in parent onChange(use in form)
  useEffect(() => {
    if (props?.onChange) {
      if (multiSelect) props.onChange(checkedNodes);
      else props.onChange(checkedNodes[0]);
    }
  }, [checkedNodes]);

  function onCheckNode(checkedNodeItems: string[], nodeInfo: OnCheckNode) {
    if (multiSelect) {
      setCheckedNodes(checkedNodeItems);
    } else {
      //@ts-ignore
      if (nodeInfo.isLeaf) {
        const isCurrentNodeChecked = !!checkedNodes.find(
          (node: string) => node === nodeInfo.value
        );
        setCheckedNodes(isCurrentNodeChecked ? [] : [nodeInfo.value]);
      }
    }
  }

  function onExpandNode(checkedNodes: string[], nodeInfo: OnExpandNode) {
    if (onExpand) onExpand(checkedNodes, nodeInfo);
    setExpandedNodes(checkedNodes);
  }

  return (
    <div className="KdTreeField">
      {nodes?.length > 0 ? (
        <CheckboxTree
          {...props}
          icons={{
            leaf: <span />,
            parentOpen: <span />,
            parentClose: <span />,
            check: (
              <MdCheckBox size={24} color={theme?.palette?.primary?.main} />
            ),
            expandOpen: <MdKeyboardArrowDown size={24} />,
            uncheck: <MdCheckBoxOutlineBlank size={24} />,
            expandClose: <MdKeyboardArrowLeft size={24} />,
            halfCheck: (
              <MdIndeterminateCheckBox
                color={theme?.palette?.primary?.main}
                size={24}
              />
            ),
          }}
          nodes={nodes}
          onCheck={onCheckNode}
          checked={checkedNodes}
          expanded={expandedNodes}
          onExpand={onExpandNode}
          showNodeIcon={true}
        />
      ) : (
        <div style={{ width: "100%", textAlign: "center" }}>{noDataText}</div>
      )}
    </div>
  );
}

export default KdTreeField;
