import { KdpaTypography } from "kdpa-components";
import Droppable from "@/core/components/DnD/Droppable";
import { useEditorStore } from "@/core/store/editorStore";
import {
  propertyExtractor,
  stylesExtractor,
} from "@/core/utils/kdlValueExtractor";

function GridPanelSearch({ id }: { id: string }) {
  const isPreview = useEditorStore((state) => state.isPreview);

  const node = useEditorStore((store) => store.nodes[id]);
  const style = stylesExtractor(node.node.style);
  const attrs = propertyExtractor(node.node.attrs);

  return (
    <div
      id={id}
      className={`w-full flex flex-col ${
        isPreview
          ? ""
          : "p-3 border border-dashed border-text_light border-opacity-30"
      }`}
    >
      <div>
        <KdpaTypography>{attrs.label}</KdpaTypography>
        <Droppable id={id} className="py-4" style={style} {...attrs} />
      </div>

      {/* <div className="self-end">
        <KdpaPrimaryButton sx={{ marginRight: "6px" }} type="submit">
          جستجو
        </KdpaPrimaryButton>
        <KdpaSecondaryButton>انصراف</KdpaSecondaryButton>
      </div> */}
    </div>
  );
}

export default GridPanelSearch;
