import { KdAlert } from "kdpa-components";

function Alert(props: any) {
  return <KdAlert {...props} />;
}

export default Alert;
