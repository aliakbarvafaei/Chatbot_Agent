import { KdHtmlEditor } from "kdpa-components";

function HtmlEditorElement(props: any) {
  return <KdHtmlEditor {...props} />;
}

export default HtmlEditorElement;
