import { useContext } from "react";
import DataTable from "react-data-table-component";
import { KdpaCheckBox, KdpaPaginationGrid } from "kdpa-components";

import {
  propertyExtractor,
  stylesExtractor,
} from "@/core/utils/kdlValueExtractor";
import { EditorElements } from "@/components/elements";
import { useEditorStore } from "@/core/store/editorStore";
import { DarkModeContext } from "@/context/DarkModeProvider";
import ElementWrapper from "@/core/components/Element/ElementWrapper";
import { customStyleKeyGenerator } from "@/components/layouts/designer/RightSideBar/tabs/StyleTab/components/EditorCss/utils";

function Element({ style, ...props }: any) {
  const nodes = useEditorStore((store) => store.nodes);
  const getNodeById = useEditorStore((store) => store.getNodeById);
  const colNodeIds = getNodeById(props.id).node.children;

  const newColumns =
    colNodeIds
      ?.map((colNodeId) => {
        const colNode = getNodeById(colNodeId);
        const colStyles = stylesExtractor(colNode.node?.style);
        const colAttrs = propertyExtractor(colNode.node?.attrs);

        if (colNode.node.children && colNode.node.children?.length > 0) {
          const celNodesId = colNode.node.children;

          return {
            id: colNodeId,
            name: (
              <ElementWrapper
                id={colNodeId}
                hoverdIcon={false}
                className="truncate"
                title={colAttrs?.label ?? ""}
              >
                {colAttrs?.label ?? ""}
              </ElementWrapper>
            ),
            cell(_: any, rowIndex: any) {
              if (colAttrs.name === "ردیف") return rowIndex + 1;
              else {
                return (
                  <>
                    {celNodesId.map((cellNode) => {
                      const Component =
                        EditorElements[nodes[cellNode].nodeType]?.component;
                      const celStyles = stylesExtractor(
                        nodes[cellNode]?.node?.style
                      );
                      const celAttrs = propertyExtractor(
                        nodes[cellNode]?.node?.attrs
                      );
                      if (Component)
                        return (
                          <ElementWrapper id={cellNode}>
                            <Component
                              id={cellNode}
                              node={getNodeById(cellNode)?.node}
                              style={celStyles}
                              {...celAttrs}
                            />
                          </ElementWrapper>
                        );
                    })}
                  </>
                );
              }
            },
            center: true,
            ...colAttrs,
            style: colStyles,
          };
        } else {
          return {
            id: colNodeId,
            name: colAttrs?.label ?? "",
            cell(_: any, rowIndex: any) {
              if (colAttrs.name === "ردیف") return rowIndex + 1;
              else {
                return <div style={colStyles}></div>;
              }
            },
            center: true,
            ...colAttrs,
          };
        }
      })
      .filter(Boolean) ?? [];

  const rowColumn = {
    name: props?.rowTitle ?? "#",
    id: "row",
    cell: (_: any, index: number) => <span>{index + 1}</span>,
    center: true,
    width: props?.rowWidth ?? null,
  };
  const selectColumn = {
    name: <KdpaCheckBox />,
    id: "row33",
    cell: () => (
      <span>
        <KdpaCheckBox />
      </span>
    ),
    center: true,
    width: props?.selectWidth ?? null,
  };

  const systemColumns = [];
  if (props?.hasRow && props?.hasSelect) {
    systemColumns.push(rowColumn);
    if (props?.selectColumnIndex === "first") {
      systemColumns.unshift(selectColumn);
    } else {
      systemColumns.push(selectColumn);
    }
  } else if (props?.hasSelect) {
    systemColumns.push(selectColumn);
  } else if (props?.hasRow) {
    systemColumns.push(rowColumn);
  }

  newColumns.unshift(...systemColumns);

  const { darkMode } = useContext(DarkModeContext);

  const paginationOptions = {
    rowsPerPageText: props?.rowsPerPageText || "",
    totalCountText: props?.totalCountText || "",
  };

  return (
    <>
      <DataTable
        noDataComponent={
          <div style={{ padding: "24px" }}>
            از بخش تنظیمات ستون‌ها و مقادیر را مشخص کنید
          </div>
        }
        {...props}
        customStyles={{
          headCells: {
            style: {
              // backgroundColor: props?.headerBgColor,
              ...(style?.[customStyleKeyGenerator("colTitleStyle")] || {}),
            },
          },
          table: {
            style: style,
          },
        }}
        theme={darkMode ? "dark" : "light"}
        data={[
          { name: "علی", age: "23" },
          { name: "حسن", age: "23" },
        ]}
        paginationComponent={() => {
          if (props.pagination) {
            return (
              <KdpaPaginationGrid
                {...paginationOptions}
                page={1}
                pageSize={10}
                totalCount={10}
                pageCount={1}
              />
            );
          } else return <></>;
        }}
        columns={newColumns}
      />
    </>
  );
}

export default Element;
