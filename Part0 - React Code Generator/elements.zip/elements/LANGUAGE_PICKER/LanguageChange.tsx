import { KdLanguageChange } from "kdpa-components";

function LanguageChange(props: any) {
  return <KdLanguageChange {...props} />;
}

export default LanguageChange;
