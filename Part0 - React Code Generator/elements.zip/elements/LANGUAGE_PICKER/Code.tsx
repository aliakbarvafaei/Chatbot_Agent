import * as Menubar from "@radix-ui/react-menubar";
import { MenubarProps } from "@radix-ui/react-menubar";
import { useState } from "react";
import "./KdLanguageChange.scss";
import IrSvg from "../../../assets/images/country/ir.svg";
import UsSvg from "../../../assets/images/country/us.svg";
import SaSvg from "../../../assets/images/country/sa.svg";

export interface KdLanguageChangeProps extends MenubarProps {
  onChange?: any;
  defaultValue?: string;
}

const KdLanguageChange = ({ defaultValue, ...props }: KdLanguageChangeProps) => {
  const [languageValue, setLanguageValue] = useState(defaultValue ?? "fa");
  const langObj: { [key: string]: string } = {
    fa: "فارسی",
    en: "English",
    ar: "العربیة",
  };

  const countryCodeHandler = (lang: string) => {
    switch (lang) {
      case "fa":
        //@ts-ignore
        return <IrSvg className="KdLanguageChange-country-flag" />;
        break;
      case "ar":
        //@ts-ignore
        return <SaSvg className="KdLanguageChange-country-flag" />;
        break;
      case "en":
        //@ts-ignore
        return <UsSvg className="KdLanguageChange-country-flag" />;
        break;
      default:
        //@ts-ignore
        return <IrSvg className="KdLanguageChange-country-flag" />;
        break;
    }
  };

  const handleChange = (lang: string) => {
    setLanguageValue(lang);
    props?.onChange(lang);
  };
  return (
    <Menubar.Root className="KdLanguageChange-MenubarRoot" dir="rtl" {...props}>
      <Menubar.Menu>
        <Menubar.Trigger className="KdLanguageChange-MenubarTrigger">
          {countryCodeHandler(languageValue)}
          {langObj[languageValue]}
        </Menubar.Trigger>
        <Menubar.Portal>
          <Menubar.Content
            align={"start"}
            side={"bottom"}
            sideOffset={10}
            className="KdLanguageChange-MenubarContent"
          >
            {Object.keys(langObj).map((item, index) => {
              return (
                <div
                  key={index}
                  className="KdLanguageChange-MenubarItem"
                  onClick={() => handleChange(item)}
                >
                  {countryCodeHandler(item)}
                  {langObj[item]}
                </div>
              );
            })}
          </Menubar.Content>
        </Menubar.Portal>
      </Menubar.Menu>
    </Menubar.Root>
  );
};

export default KdLanguageChange;
