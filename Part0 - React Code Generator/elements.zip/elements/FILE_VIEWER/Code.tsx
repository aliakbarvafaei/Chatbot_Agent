import { styled } from "@mui/system";
import { BsImage } from "react-icons/bs";

import { useEffect, useState } from "react";
import { KdpaPdfViewer } from "../../../components";
import { fileExtension } from "../../utils";
import { Dialog, DialogContent } from "@mui/material";
import { fetchFilesProperty } from "../../../designerKit/utils/sharedUtils";

const StyledImage = styled("img")();
const StyledDiv = styled("div")();

export interface KdFileViewerProps {
  src: string;
  modal?: boolean;
  extention?: string;
  basePath?: {
    basePathStream?: string;
    basePathThumbnail?: string;
  };
  pathProp?: {
    APIURL: string;
  };
  [x: string]: any;
}

function FullScreenDialog({
  children,
  open,
}: {
  children: React.ReactNode;
  open: boolean;
}) {
  return (
    <Dialog open={open} fullScreen>
      <DialogContent sx={{ padding: "0px" }}>{children}</DialogContent>
    </Dialog>
  );
}

function KdFileViewer({
  src,
  modal = false,
  basePath,
  pathProp,
  ...props
}: KdFileViewerProps) {
  const [fileInfo, setFileInfo] = useState({
    fileType: "",
    extention: "",
  });
  const [openModal, setOpenModal] = useState(false);

  useEffect(() => {
    const fetchAndSetFileProperties = async () => {
      if (src && pathProp?.APIURL) {
        const data = await fetchFilesProperty(pathProp.APIURL, [src]);
        const fileName = (data ?? []).find(
          (el: any) => el.guid === src
        )?.fileName;
        const extention = fileName && fileName?.split(".").pop();

        setFileInfo({
          extention: extention,
          fileType:
            (
              Object.keys(fileExtension) as Array<keyof typeof fileExtension>
            ).find((key) => fileExtension[key].includes(extention)) ?? "",
        });
      }
    };

    fetchAndSetFileProperties();
  }, [src]);

  const handleUrlImage = (size: "small" | "large"): string => {
    if (size === "small") {
      if (basePath?.basePathThumbnail) return basePath?.basePathThumbnail + src;
      else return src as string;
    } else {
      if (basePath?.basePathStream) return basePath?.basePathStream + src;
      else return src as string;
    }
  };

  if (!src) {
    return (
      <StyledDiv sx={{ ...props?.style, ...props?.sx }}>
        <BsImage style={{ color: "gray", height: "100%", width: "100%" }} />
      </StyledDiv>
    );
  }

  function renderViewer() {
    if (fileInfo.fileType === "text" && fileInfo.extention === "pdf") {
      return (
        <KdpaPdfViewer
          handleClose={() => setOpenModal(false)}
          fileUrl={handleUrlImage("large")}
        />
      );
    }
  }

  const Component = renderViewer();

  if (modal === true) {
    return (
      <>
        <StyledImage
          {...props}
          src={handleUrlImage("small")}
          onClick={() => Component && setOpenModal(true)}
        />
        {Component && (
          <FullScreenDialog open={openModal}>{Component}</FullScreenDialog>
        )}
      </>
    );
  } else if (Component) {
    if (Component) return <StyledDiv {...props}>{Component}</StyledDiv>;
  } else <StyledImage {...props} src={handleUrlImage("small")} />;
}

export default KdFileViewer;
