import { KdCaptcha } from "kdpa-components";
import { env } from "../../../../env";

function Captcha(props: any) {
  const { VITE_APIURL: DOMAIN } = env;

  const randomNumber = Math.floor(Math.random() * 1000);
  return (
    <KdCaptcha
      {...props}
      pathProp={{ APIURL: DOMAIN }}
      randomNumber={randomNumber}
    />
  );
}

export default Captcha;
