import React from "react";
import { captchaPath } from "../../utils/sharedUtils";

import { styled } from "@mui/system";

const StyledImage = styled("img")();

export type KdCaptchaProps = {
  pathProp: {
    APIURL: string;
  };
  randomNumber: number;
};

const KdCaptcha: React.FC<KdCaptchaProps> = ({
  pathProp,
  randomNumber,
  ...props
}) => {
  return (
    <StyledImage
      {...props}
      alt="CAPTCHA"
      src={`${pathProp.APIURL}${captchaPath}${randomNumber}`}
    />
  );
};

export default KdCaptcha;
