import { KdpaTypography } from "kdpa-components";

function Label(props: any) {
  return <KdpaTypography component={"label"} {...props} sx={props?.style} />;
}

export default Label;
