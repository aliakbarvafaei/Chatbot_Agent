import React from "react";
import InputLabel, { InputLabelProps } from "@mui/material/InputLabel";

export type KdpaInputLabelProps = InputLabelProps;

function KdpaInputLabel(props: InputLabelProps) {
  return <InputLabel {...props}>{props.children}</InputLabel>;
}

export default KdpaInputLabel;
