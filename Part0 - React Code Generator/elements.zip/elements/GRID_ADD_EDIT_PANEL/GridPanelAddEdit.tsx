import Droppable from "@/core/components/DnD/Droppable";
import { useEditorStore } from "@/core/store/editorStore";

function GridPanelAddEdit(props: any) {
  const isPreview = useEditorStore((state) => state.isPreview);

  return (
    <div
      {...props}
      className={`w-full flex flex-col ${
        isPreview
          ? ""
          : "p-3 border border-dashed border-text_light border-opacity-30"
      }`}
    >
      <Droppable id={props.id} />
    </div>
  );
}

export default GridPanelAddEdit;
