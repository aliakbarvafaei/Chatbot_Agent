import { memo } from "react";

import { KdpaTypography, KdFormContainer } from "../../../components";

import KdPanelWrapper from "./KdPanelWrapper";

export interface KdGridPanelProps {
  isOpen: boolean;
  children: React.ReactNode;
  onClose: () => void;
  label: string;
  loading: boolean;
  panelType: string;
  onSubmit: (data: any) => void;
  [x: string]: any;
}

function KdGridPanel({
  isOpen = false,
  children,
  onClose,
  label,
  loading = false,
  onSubmit,
  ...props
}: KdGridPanelProps) {
  return (
    <KdPanelWrapper
      isOpen={!!isOpen}
      onClose={onClose}
      label={label}
      {...props}
    >
      <KdFormContainer
        onSubmit={onSubmit}
        loading={loading}
        formState={props.formState}
        {...props}
      >
        <div>
          <header style={{ padding: "12px", borderBottom: "1px solid #eee" }}>
            <KdpaTypography variant="h6" fontSize={"16px"}>
              {label}
            </KdpaTypography>
          </header>

          {children}
        </div>
      </KdFormContainer>
    </KdPanelWrapper>
  );
}

export default memo(KdGridPanel);
