import {
  MdExpandLess as ExpandLessIcon,
  MdChevronLeft as ChevronLeftIcon,
} from "react-icons/md";
import { TreeView, TreeViewProps } from "@mui/x-tree-view/TreeView";
import { TreeItem } from "@mui/x-tree-view/TreeItem";

import { BuildTreeType, useTreeHelper } from "./useTreeHelper";
import { ComponentType, CSSProperties } from "react";

export interface KdTreeProps extends TreeViewProps<false> {
  data: unknown[];
  onClick?: (...$args: any[]) => void;
  getOptionLabel?: ((data: any) => string) | undefined;
  getOptionIcon?: ((data: any) => string) | undefined;
  getOptionValue?: ((data: any) => string) | undefined;
  getOptionParent?: ((data: any) => string) | undefined;
  getOptionNavlink?: ((data: any) => string) | undefined;
  getOptionExternalLink?: ((data: any) => boolean) | undefined;
  noDataText?: string;
  treeItemContentStyle?: CSSProperties;
  treeItemLabelStyle?: CSSProperties;
  LinkComponent?: ComponentType<any>; // Add LinkComponent prop
  hoverTextColor?: string;
  hoverBackgroundColor?: string;
  focusedTextColor?: string;
  focusedBackgroundColor?: string;
  [key: string]: any;
}
function KdTree({
  data,
  onClick,
  getOptionValue,
  getOptionIcon,
  getOptionLabel,
  getOptionParent,
  getOptionNavlink,
  getOptionExternalLink,
  noDataText = "no data",
  LinkComponent, // Destructure LinkComponent prop
  hoverBackgroundColor,
  hoverTextColor,
  focusedBackgroundColor,
  focusedTextColor,
  ...props
}: KdTreeProps) {
  const { buildTree, renderTreeToSpecificFieldName } = useTreeHelper();
  const nodes = buildTree(
    renderTreeToSpecificFieldName({
      data,
      getOptionLabel,
      getOptionIcon,
      getOptionValue,
      getOptionParent,
      getOptionNavlink,
      getOptionExternalLink,
    })
  );

  const LeafWrapperTreeItem = ({
    data,
    children,
    isLeaf,
  }: {
    data: BuildTreeType;
    children: any;
    isLeaf?: boolean;
  }) => {
    if (!isLeaf) return <>{children}</>;
    // comming soon add Link tag from react router dom
    const TagName =
      onClick || !data.navlink
        ? "span"
        : data.externalLink
        ? "a"
        : LinkComponent || "a";

    const TagProp = onClick
      ? {
          onClick: () => {
            onClick(data);
          },
        }
      : data.externalLink || !LinkComponent
      ? { href: data.navlink }
      : { to: data.navlink }; // use "to" prop for LinkComponent

    return (
      <TagName
        {...TagProp}
        style={{ textDecoration: "none", color: "inherit" }}
      >
        {children}
      </TagName>
    );
  };

  const renderTree = (nodes: BuildTreeType[]) => {
    return nodes.map((node) => {
      return (
        <LeafWrapperTreeItem
          isLeaf={!(node.children && node.children.length > 0)}
          data={node}
        >
          <TreeItem
            key={node.value}
            nodeId={node.value}
            label={node.label}
            sx={{
              "& .MuiTreeItem-content": {
                flexDirection: "row-reverse",
                padding: "10px 15px",
                ...(props.treeItemContentStyle ?? {}),
              },
              ...(hoverBackgroundColor && {
                "& .MuiTreeItem-content:hover": {
                  backgroundColor: hoverBackgroundColor,
                  color: hoverTextColor,
                },
              }),
              ...(focusedBackgroundColor && {
                "& .MuiTreeItem-content.Mui-focused": {
                  backgroundColor: focusedBackgroundColor,
                  color: focusedTextColor,
                },
              }),
              "& .MuiTreeItem-label": {
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                gap: "4px",
                ...(props.treeItemLabelStyle ?? {}),
              },
            }}
          >
            {node.children &&
              node.children.length > 0 &&
              renderTree(node?.children)}
          </TreeItem>
        </LeafWrapperTreeItem>
      );
    });
  };

  return (
    <KdpaGrid>
      <KdpaGrid>
        <KdImageBox src="logo.png" />
        <KdTypography>Website Title</KdTypography>
      </KdpaGrid>
      <KdpaGrid>
        <KdpaGrid>
          <KdpaIconButton>
            <MdOutlineHomeIcon />
          </KdpaIconButton>
          <KdTypography>Link to Shop Page</KdTypography>
        </KdpaGrid>
        <KdpaGrid>
          <KdpaIconButton>
            <MdOutlineInfoIcon />
          </KdpaIconButton>
          <KdTypography>Link to About Us Page</KdTypography>
        </KdpaGrid>
        <KdpaGrid>
          <KdpaIconButton>
            <MdOutlineContactMailIcon />
          </KdpaIconButton>
          <KdTypography>Link to Contact Us Page</KdTypography>
        </KdpaGrid>
        <KdpaGrid>
          <KdpaPrimaryButton>Login</KdpaPrimaryButton>
        </KdpaGrid>
      </KdpaGrid>
    </KdpaGrid>
  );
}

export default KdTree;
