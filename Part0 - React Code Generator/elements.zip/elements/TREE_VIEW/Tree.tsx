import { KdTree } from "kdpa-components";
import { useEditorStore } from "@/core/store/editorStore";
import { useTranslation } from "react-i18next";
import { contentToKeyword } from "@/core/hooks/useElementPropertyTranslate";
import useIconLoader from "@/components/commons/IconPicker/Loader/useIconLoader";
import { generateIconString } from "@/utility/shared";

function Tree(props: any) {
  const { t } = useTranslation();
  const multiLanguage = useEditorStore((store) => store.appInfo.multiLanguage);
  const translates = useEditorStore((store) => store.translates);
  const listValueDisplayName = useEditorStore(
    (store) => store.nodes[props.id].meta.listValueDisplayName
  );

  const listValueConstant = useEditorStore(
    (store) => store.nodes[props.id].meta.listValueConstant
  );
  let data = [];
  if (
    listValueConstant &&
    typeof listValueConstant === "string" &&
    listValueConstant !== "null"
  )
    data = (JSON.parse(listValueConstant) ?? [])?.map((element: any) => {
      const iconString = generateIconString(element.icon);

      const Icon = iconString && useIconLoader(iconString);
      return {
        ...element,
        navlink: null,
        icon: Icon && <Icon />,
        label:
          multiLanguage === "MULTI" &&
          translates[contentToKeyword(element.label).keyword] !== undefined
            ? translates[contentToKeyword(element.label).keyword]
            : element.label,
      };
    });

  return (
    <KdTree
      data={data}
      hoverBackgroundColor={props.hoverBackgroundColor}
      focusedBackgroundColor={props.focusedBackgroundColor}
      hoverTextColor={props.hoverTextColor}
      focusedTextColor={props.focusedTextColor}
      getOptionLabel={(data: any) => data.label}
      getOptionIcon={(data: any) => data.icon}
      getOptionValue={(data: any) => data.value}
      getOptionParent={(data: any) => data.parent}
      getOptionNavlink={(data: any) => data.navlink}
      getOptionExternalLink={(data: any) => data.externalLink}
      noDataText={
        data.length > 0
          ? t("common.not_correct_data_format")
          : listValueDisplayName
          ? t("common.DATA_SOURCE")
          : t("common.set_data_source_tree")
      }
    />
  );
}

export default Tree;
